<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Active Task</h1>
    </div>

    <Footer/>
    </v-app>
  </v-card>
</template>

<script>
</script>

<style>

</style>