<template>
  <form name="login-form">
    <h1>Please enter your 4 Digit Authentication Code</h1>
   
    <div>
      <label for="code">Enter code:</label>
      <input id="code" type="number" v-model="input.code" class="code" autocomplete="off"  placeholder="####"> 
    </div>

    <button type="submit" v-on:click.prevent = "login()">Login</button>
  </form>
   <p id="msg"></p>
   <p id="msg" v-if="this.$store.state.error"> {{this.$store.state.error }} </p>
</template>

<script>
export default {
  name: 'AuthenticationCode',

  data() {
    return {
      input: {
        code: ""
      }
    }
  },

  methods: {
    login() {
      const code = this.input.code 
      this.$store.commit('authenticationCode', code)
    },
    }
    }
</script>

<style scoped>
  h1 {
  text-align: center;
  line-height: 2.15rem;
 }

  form {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
    padding: 2rem;
    text-align: center;
  }

  form input {
    background-color: rgba(0,170,162);
    border-radius: 1rem;
  }  

  form button {
    text-transform: uppercase;
    font-weight: bold;
  }

  .code {
    inline-size: 100%;
    text-align: center;
  }

  #msg {
    text-align: center;
    inline-size: 75%;
    padding-block: 1rem;
    margin: 0 auto;
    border-radius: 1rem;
    color: red;
    font-weight: bold;
    text-transform: uppercase;
  }

</style>