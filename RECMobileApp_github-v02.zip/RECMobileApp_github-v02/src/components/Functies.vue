<template>
<div class="container">
  <!-- Items -->
<router-link to="/scheduled">
  <button class="item">
    <v-icon>mdi-bookmark-outline</v-icon>
   <p>Scheduled</p>
  </button>
</router-link>

<router-link to="/completed">
  <button class="item">
    <v-icon>mdi-check-circle</v-icon>
    <p>Completed</p>
  </button>
</router-link>

<router-link to="/knowledge-base">
 <button class="item">
    <v-icon>mdi-grid</v-icon>
    <p>Knowledge base</p>
  </button>
</router-link>

<router-link to="/settings">
  <button class="item">
    <v-icon>mdi-cog</v-icon>
    <p>Settings</p>
  </button>
</router-link>

</div>
</template>

<script setup>
</script>

<style scoped>
  .container {
    margin-block-start: 85px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    justify-content: center;
    gap: 1em;
    padding: 1em;
    background-color: rgb(255, 255, 255);
  }

  .v-icon {
    font-size: 150px;
    color: rgba(20,27,31);
  }

  .item {
    height: 275px;
    inline-size: 45vw;
    background-color: rgb(255, 255, 255);
    box-shadow: 1px 1px 3px #888888;
    border-radius: 10px;
  }

  p {
    color: rgba(20,27,31);
  }

  a {
  text-decoration: none;
  }
</style>
