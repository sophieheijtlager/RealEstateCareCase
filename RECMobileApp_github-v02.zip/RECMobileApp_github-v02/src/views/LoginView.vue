<template>
  <form name="login-form">
    <h1>Please enter your Username and Password</h1>
    <div>
      <label for="username">Username:</label>
      <input id="username" type="text" v-model="input.username" autocomplete="off" autofocus>
    </div>

    <div>
      <label for="password">Password:</label>
      <input id="password" type="password" v-model="input.password">
    </div>

    <button type="submit" v-on:click.prevent = "login()">Login</button>
    <p></p>
  </form>

    <p id="msg" v-if="this.$store.state.error"> {{this.$store.state.error }} </p>
</template>

<script>
export default {
  name: 'LoginView',

  data() {
    return {
      input: {
        username: "",
        password: "",
      }
    }
  },

  methods: {
    login() {
      // username or password are not empty
      const details = {
        username: this.input.username,
        password: this.input.password
      }

      this.$store.commit('authenticate', details)
    }
   }
  }

</script>

<style scoped>
  h1 {
  text-align: center;
  line-height: 2.15rem;
 }
  form {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
    padding: 2rem;
    margin-block-end: 4rem;
  }

  form input {
    background-color: rgba(0,170,162);
    border-radius: 1rem;
    margin-inline-start: 1rem;

    padding-inline-start: 1rem;
  }  

  form button {
    text-transform: uppercase;
    font-weight: bold;
  }

  #msg {
    text-align: center;
    inline-size: 75%;
    padding-block: 1rem;
    margin: 0 auto;
    border-radius: 1rem;
    color: red;
    font-weight: bold;
    text-transform: uppercase;
  }
</style>