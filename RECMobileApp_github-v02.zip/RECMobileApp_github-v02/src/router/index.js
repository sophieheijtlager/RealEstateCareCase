import { createRouter, createWebHistory } from "vue-router";

// Import Components
import Home from "../views/Home.vue";
import Settings from "../views/Settings.vue";
import Notifications from "../views/Notifications.vue";

import Completed from "../views/Completed.vue";
import KnowledgeBase from "../views/KnowledgeBase.vue";
import Scheduled from "../views/Scheduled.vue";

import ActiveTask from "../views/ActiveTask.vue";
import Search from "../views/Search.vue";
import Information from "../views/Information.vue";

import LoginView from "../views/LoginView.vue";
import AuthenticationCode from "../views/AuthenticationCode.vue"

import auth from '@/store/auth';

const routes = [
  // All routes go here
  {
    path: '/',
    name: 'Login',
    component: LoginView,
  },

  {
    path: '/home',
    name: 'Home',
    component: Home,
  },

  {
    path: '/code',
    name: 'Code',
    component: AuthenticationCode,
  },


  {
    path: '/settings',
    name: 'Settings',
    component: Settings,
  },

  {
    path: '/notifications',
    name: 'Notifications',
    component: Notifications,
  },

  {
    path: '/completed',
    name: 'Completed',
    component: Completed,
  },

  {
    path: '/knowledge-base',
    name: 'KnowledgeBase',
    component: KnowledgeBase,
  },

  {
    path: '/scheduled',
    name: 'Scheduled',
    component: Scheduled,
  },

  {
    path: '/active-task',
    name: 'ActiveTask',
    component: ActiveTask,
  },

  {
    path: '/search',
    name: 'Search',
    component: Search,
  },

  {
    path: '/information',
    name: 'Information',
    component: Information,
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes: routes,
  linkActiveClass: 'active'
});

router.beforeEach((to, from) => {
  // redirect to login page + home page
  const isAuthenticated = auth.getters.isAuthenticated
  
  if (!isAuthenticated && to.name !== 'Login')  {
    return { name: 'Login' }
  }

  if (isAuthenticated && to.name == 'Login') {
    return { name: 'Home'}
  }
})

export default router;