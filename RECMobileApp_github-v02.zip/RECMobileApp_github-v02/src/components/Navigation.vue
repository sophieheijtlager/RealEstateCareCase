<template>
    <!-- TOP CONS BAR -->
    <v-system-bar>
      <v-icon>mdi-square</v-icon>
      <v-icon>mdi-circle</v-icon>
      <v-icon>mdi-triangle</v-icon>
    </v-system-bar>

    <!-- NAVBAR -->
    <v-app-bar>

      <!-- Logo  -->
        <v-app-bar-title>
          <router-link to="/home" id="logo"
          ><img src="/src/assets/mainLogoREC-3.svg" alt="RealEstateCareLogo" ></router-link>
        </v-app-bar-title>

      <!-- Bell Icon -->
      <router-link to="/notifications">
      <v-btn icon class="icon">
        <v-icon>mdi-bell</v-icon>
      </v-btn>
      </router-link>

      <!-- Settings Icon -->
      <router-link to="/settings">
      <v-btn icon class="icon">
        <v-icon>mdi-cog</v-icon>
      </v-btn>
      </router-link>
 
    </v-app-bar>
</template>

<script setup>
</script>

<style scoped>  
.v-app-bar-title img {
  inline-size: 200px;
  display: flex;
}

.v-system-bar {
  background-color: rgba(0,170,162);
}

.v-img {
  background-color: rgb(50, 104, 101);
}

.icon {
  color: rgba(0,170,162);
}
</style>
