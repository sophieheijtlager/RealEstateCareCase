<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Settings</h1>
     <v-btn @click="toggleTheme">toggle theme</v-btn>
    </div>

    <Footer/>
    </v-app>

  </v-card>
</template>

<script setup>
import Footer from '@/components/Footer.vue';
import Navigation from '@/components/Navigation.vue';
import { useTheme } from 'vuetify';

const theme = useTheme()

function toggleTheme () {
  theme.global.name.value = theme.global.current.value.dark ? 'light' : 'dark';
}
</script>

<style scoped>
</style>