<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>
    <Functies/>
    <Footer/>
    </v-app>
  </v-card>
</template>

<script setup>
  import Navigation from '../components/Navigation.vue'
  import Functies from '../components/Functies.vue';
  import Footer from '../components/Footer.vue';

  import { ref } from 'vue' 

  const drawer = ref(null);
</script>

<style scoped>
</style>