<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Knowledge Base</h1>
    </div>

    <Footer/>
    </v-app>
  </v-card>

  <!-- 
    Deze pagina bevat relevante bestanden met betrekking tot inspecties, van normbladen tot testprocedures
   -->
</template>

<script>
import Footer from '@/components/Footer.vue';
import Navigation from '@/components/Navigation.vue';

export default {
  name: "KnowledgeBase",

  components: {
    Navigation,
    Footer
  }
}
</script>

<style>

</style>