  <template>
    <v-bottom-navigation>
      <router-link to="/active-task">
      <v-btn>
        <v-icon>mdi-wrench</v-icon>
        Active Task
      </v-btn>
      </router-link>


      <router-link to="/search">
      <v-btn>
        <v-icon>mdi-magnify</v-icon>
        Search
      </v-btn>
      </router-link>


      <router-link to="/information">
      <v-btn>
        <v-icon>mdi-alert-circle</v-icon>
        Information
      </v-btn>
      </router-link>     
    </v-bottom-navigation>
</template>

<script setup>
</script>

<style scoped>
  .v-btn {
    text-transform: none; 
    font-size: 0.75rem;
    margin-inline: 1rem;
  }

  a {
    display: flex;
    align-items: center;

    text-decoration: none;
  }

  .v-btn {
     color: rgba(0,170,162);
  }
</style>