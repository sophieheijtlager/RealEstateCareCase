<template>
<v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Completed Inspections</h1>
     <ul>
        <li v-for="inspection of inspections" :key="inspection.id">
         <span class="date">{{inspection.date}}</span> {{inspection.inspectionType + " on "}} 
        </li>
    </ul>
    </div>

    <Footer/>
    </v-app>
  </v-card>

</template>

<script>
import inspections from '@/services/inspections'

export default {
  data() {
    return {
      inspections: []
    }
  },

  async created() {
    try {
      const inspectionsData = await inspections.getCompletedInspections()
      this.inspections = inspectionsData
    } catch (error) {
      console.log(error)
    }
  }
}


</script>

<style scoped>
 .main-content {
    margin-block-start: 6rem;
    margin-inline-start: 1rem;
 }

 ul {
   padding-inline-start: 1.25rem;
 }

 li {
  padding: 0;
  margin-block-end: 1rem;
 }

 li:hover {
  opacity: 0.75;
 }

  .date {
  font-weight: bold;
  color: rgba(0,170,162);
 }
</style>
