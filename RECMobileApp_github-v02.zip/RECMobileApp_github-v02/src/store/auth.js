import router from "@/router";
import { createStore } from "vuex";

const authStore = createStore({
  state () {
    return {
      authenticated: sessionStorage.getItem('authenticated'),
      error: false
    }
  },

  mutations: {
    authenticate (state, details) {

      if (details.username === "Real" && details.password === "Estate") {
        state.authenticated = true;
        state.error = false;

        router.push('/code')

      } else {
        state.error = 'Incorrect';
      }
    },

    authenticationCode (state, code) {
      if (!code || code !== 1234) {
        state.error = 'Incorrect Code';
        return;
      }

      if (code === 1234) {
        state.authenticated = true;
        sessionStorage.setItem('authenticated', true)
        
        router.push('/home')
      }
    }
  },

  getters: {
    isAuthenticated(state) {
      return state.authenticated
    }
  }
});

export default authStore;