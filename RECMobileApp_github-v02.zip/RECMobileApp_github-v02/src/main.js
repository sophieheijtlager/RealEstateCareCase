/**
 * main.js
 *
 * Bootstraps Vuetify and other plugins then mounts the App`
 */

// Plugins
import { registerPlugins } from '@/plugins'

import { createApp } from 'vue'
import App from './App.vue'

import router from './router';
import auth from '../src/store/auth';

const app = createApp(App);

registerPlugins(app);

app.use(router).use(auth)
.mount('#app')
