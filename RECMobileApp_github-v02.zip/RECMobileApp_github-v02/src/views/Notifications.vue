<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Notifications</h1>
    </div>

    <Footer/>
    </v-app>
  </v-card>
</template>

<script>
import Footer from '@/components/Footer.vue';
import Navigation from '@/components/Navigation.vue';

export default {
  name: "Notifications",

  components: {
    Navigation,
    Footer
  }
}
</script>

<style>

</style>