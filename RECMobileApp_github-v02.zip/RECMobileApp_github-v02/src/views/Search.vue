<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Search</h1>
    </div>

    <Footer/>
    </v-app>
  </v-card>

</template>

<style scoped>
</style>