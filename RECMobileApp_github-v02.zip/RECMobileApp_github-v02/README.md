# Vuetify (Default)

This is the official scaffolding tool for Vuetify, designed to give you a head start in building your new Vuetify application. It sets up a base template with all the necessary configurations and standard directory structure, enabling you to begin development without the hassle of setting up the project from scratch.

## ❗️ Important Links

- 📄 [Docs](https://vuetifyjs.com/)
- 🚨 [Issues](https://issues.vuetifyjs.com/)
- 🏬 [Store](https://store.vuetifyjs.com/)
- 🎮 [Playground](https://play.vuetifyjs.com/)
- 💬 [Discord](https://community.vuetifyjs.com)

## 💿 Install

Set up your project using your preferred package manager. Use the corresponding command to install the dependencies:

| Package Manager                                                | Command        |
|---------------------------------------------------------------|----------------|
| [yarn](https://yarnpkg.com/getting-started)                   | `yarn install` |
| [npm](https://docs.npmjs.com/cli/v7/commands/npm-install)     | `npm install`  |
| [pnpm](https://pnpm.io/installation)                          | `pnpm install` |
| [bun](https://bun.sh/#getting-started)                        | `bun install`  |

After completing the installation, your environment is ready for Vuetify development.

## ✨ Features

- 🖼️ **Optimized Front-End Stack**: Leverage the latest Vue 3 and Vuetify 3 for a modern, reactive UI development experience. [Vue 3](https://v3.vuejs.org/) | [Vuetify 3](https://vuetifyjs.com/en/)
- 🗃️ **State Management**: Integrated with [Pinia](https://pinia.vuejs.org/), the intuitive, modular state management solution for Vue.
- 🚦 **Routing and Layouts**: Utilizes Vue Router for SPA navigation and vite-plugin-vue-layouts for organizing Vue file layouts. [Vue Router](https://router.vuejs.org/) | [vite-plugin-vue-layouts](https://github.com/JohnCampionJr/vite-plugin-vue-layouts)
- ⚡ **Next-Gen Tooling**: Powered by Vite, experience fast cold starts and instant HMR (Hot Module Replacement). [Vite](https://vitejs.dev/)
- 🧩 **Automated Component Importing**: Streamline your workflow with unplugin-vue-components, automatically importing components as you use them. [unplugin-vue-components](https://github.com/antfu/unplugin-vue-components)

These features are curated to provide a seamless development experience from setup to deployment, ensuring that your Vuetify application is both powerful and maintainable.

## 💡 Usage

This section covers how to start the development server and build your project for production.

### Starting the Development Server

To start the development server with hot-reload, run the following command. The server will be accessible at [http://localhost:3000](http://localhost:3000):

```bash
yarn dev
```

(Repeat for npm, pnpm, and bun with respective commands.)

> Add NODE_OPTIONS='--no-warnings' to suppress the JSON import warnings that happen as part of the Vuetify import mapping. If you are on Node [v21.3.0](https://nodejs.org/en/blog/release/v21.3.0) or higher, you can change this to NODE_OPTIONS='--disable-warning=5401'. If you don't mind the warning, you can remove this from your package.json dev script.

### Building for Production

To build your project for production, use:

```bash
yarn build
```

(Repeat for npm, pnpm, and bun with respective commands.)

Once the build process is completed, your application will be ready for deployment in a production environment.

## 💪 Support Vuetify Development

This project is built with [Vuetify](https://vuetifyjs.com/en/), a UI Library with a comprehensive collection of Vue components. Vuetify is an MIT licensed Open Source project that has been made possible due to the generous contributions by our [sponsors and backers](https://vuetifyjs.com/introduction/sponsors-and-backers/). If you are interested in supporting this project, please consider:

- [Requesting Enterprise Support](https://support.vuetifyjs.com/)
- [Sponsoring John on Github](https://github.com/users/johnleider/sponsorship)
- [Sponsoring Kael on Github](https://github.com/users/kaelwd/sponsorship)
- [Supporting the team on Open Collective](https://opencollective.com/vuetify)
- [Becoming a sponsor on Patreon](https://www.patreon.com/vuetify)
- [Becoming a subscriber on Tidelift](https://tidelift.com/subscription/npm/vuetify)
- [Making a one-time donation with Paypal](https://paypal.me/vuetify)

## 📑 License
[MIT](http://opensource.org/licenses/MIT)

Copyright (c) 2016-present Vuetify, LLC

------------------------------------------------

1. Stappenplan
Om deze applicatie succesvol te kunnen tonen, type je de volgende prompts in de terminal:
- npm run dev
- json-server completed-inspections-data.json
- json-server -p 4000 scheduled-inspections-data.json

- Vuetify moet geïnstalleerd worden
- Axios moet geïnstalleerd worden
- Vuex moet geïnstalleerd worden
- Vue Router moet geïnstalleerd worden

2. Korte Evaluatie - Toepassing security, usability, accessibility en style guides + best practices
In de applicatie heb ik geprobeerd zoveel mogelijk rekening te houden met het toepassen van security, usability, accessibility en style guides + best practices. 



Security:
Ik heb een login-systeem opgezet waarin een gebruiker bij een ojuiste gebruikersnaam of wachtwoord een foutmelding op de pagina te zien krijgt. Daarnaast is er een pagina voor tweestapsverificatie, waar de gebruiker een 4-cijferige code moet invoeren. Ook hier wordt gecontroleerd of de ingevoerde code juist is.

Zowel op de login-pagina als op de code-pagina kan de gebruiker niet verder naar de applicatie navigeren zonder succesvol in te loggen.



Usability en Accessibility: 
Om de gebruiksvriendelijkheid (usability) en toegankelijkheid (accessibility) van de applicatie te verbeteren, heb ik ervoor gezorgd dat gebruikers na een succesvolle login niet opnieuw hoeven in te loggen tijdens hun sessie. Dit maakt het proces efficiënter en vermindert herhaalde handelingen.

Daarnaast is de applicatie ontworpen met een visuele interface. De opzet is eenvoudig, met vier verschillende secties en een consistente header en footer die op elke pagina aanwezig zijn. Deze consistentie draagt bij aan een duidelijk navigatie-ervaring voor de gebruiker.

Om tegemoet te komen aan verschillende voorkeuren, biedt de applicatie ook een 'dark mode' en 'light mode'. Gebruikers kunnen eenvoudig wisselen tussen deze weergave bij de settings, zodat ze de interface kunnen aanpassen aan hun visuele voorkeuren of omgevingslicht. Dit bevordert zowel het comfort als de toegankelijkheid van de applicatie.



Style Guides en Best Practices:
Om de style guides en best practices zorgvuldig toe te passen, heb ik een aantal van de WCAG 2.1 Niveau A richtlijnen geïmplementeerd, evenals de aanbevolen best practices voor Vue. Deze maatregelen bevorderen zowel de toegankelijkheid als de onderhoudbaarheid van de applicatie.

Ten eerste heb ik duidelijke en informatieve paginatitels toegevoegd, zodat gebruikers direct kunnen zien op welke pagina ze zich bevinden. Daarnaast is de functionaliteit van links helder gecommuniceerd in de header, footer en secties, zodat gebruikers precies weten waar een link hen naartoe leidt. Ook is de applicatie geschreven in een begrijpelijke en toegankelijke taal, wat het navigeren en gebruiken eenvoudiger maakt voor een breed publiek. Bovendoen hoeven gebruikers niet opnieuw in te loggen als ze al zijn ingelogd, wat de alghele gebruikerservaring verbetert en de workflow efficiënter maakt.

Ook heb ik een aantal van de Vue best practices toegepast. Zo gebruik is PascalCase voor de naamgeving van Vue-Components, waardoor de code consistent en goed leesbaar blijft. Daarnaast vermijd ik het mixen van v-if en v-for in templates, wat bijdraagt aan een betere prestaties en duidelijkere logica in de code. De bestanden zijn verder logisch gestructureerd en opgesplitst in kleinere, overzichtelijkere Components, zodat de code gemakkelijk te onderhouden is.

Ten slotte heb ik Routing geïmplementeerd om een vlotte en intuïtieve navigatie tussen verschillende pagina's mogelijk te maken. Dit zorgt ervoor dat gebruikers eenvoudig door de applicatie kunnen bewegen zonder complexiteit en maakt het onderhoud van de applicatie overzichtelijk voor ontwikkelaars.



Conclusie:
Over het algemeen ben ik tevreden met hoe ik de security, usability, accessibility en style guides + best practices heb geïntegreerd in de applicatie. Er zijn echter nog enkele punten die ik niet heb kunnen realiseren of waar ik nog niet aan toe ben gekomen.

Een van de aandachtspunten betreft de 4-cijferige authenticatiecode. Op dit moment is het mogelijk om meer dan vier cijfers in te voeren, wat niet de bedoeling is. Dit probleem moet nog worden aangepakt om ervoor te zorgen dat gebruikers exact vier cijfers kunnen invoeren voor de tweestapsverificatie.

Daarnaast is er een probleem met de navigatie wanneer een gebruiker is ingelogd. Hoewel de gebruiker succesvol ingelogd is, kan hij/zij nog steeds teruggaan naar de pagina voor de authenticatiecode, wat verwarrend kan zijn. 

Een ander verbeterpunt betreft de visuele aanpassing van de applicatie. Hoewel er een 'dark mode' en een 'light mode' is ingebouwd, veranderen de kleuren van de icoontjes en afbeeldingen in de header en footer nog niet wanneer de gebruiker toggelt tussen de thema's. 


---------------------------------------------------------------------------------------------------------------------------------------------------------

EINDCONCLUSIE EN ERVARINGEN: 
Over het algemeen is het bouwen van de applicatie mij goed afgegaan en heb ik het proces als positief ervaren. Het was prettig om de applicatie stapsgewijs op te bouwen, waarbij regelmatige feedbackmomenten hielpen om de voortgang te evalueren en verbeteringen door te voeren. Deze iteratieve aanpak zorgde ervoor dat ik continu kon bijsturen en nieuwe inzichten kon toepassen tijdens de ontwikkeling.

Een van de meest uitdagende onderdelen vond ik het verwerken en ophalen van de inspections-data via een combinatie van een service, store en API. Dit bleek complexer dan verwacht en het heeft enige tijd gekost voordat de data correct werd opgehaald en succesvol op de pagina's werd weergegeven. Uiteindelijk lukte het, maar dit onderdeel vereist diepere technische kennis.

Ondanks deze uitdaging kijk ik met tevredenheid terug op de eindopdracht. Ik vond het een goede balans tussen enerzijds het stylen van de website en anderzijds het implementeren van de logica achter de functionaliteiten. Deze opdracht bood voldoende ruimte om creatief te zijn terwijl ik tegelijkertijd werd uitgedaagd om technische problemen op te lossen.

Al met al was het een leerzaam en waardevol proces waarin ik mijn vaardigheden heb kunnen verbeteren.




