<template>
  <v-card class="mx-auto" color="grey-lighten-3">
    <v-app> 
    <Navigation/>

    <div class="main-content">
     <h1>Information</h1>
     <p>RealEstateCare is a service-oriented organization that maintains, improves, and inspects properties on behalf of various clients, 
      such as housing associations and real estate developers.</p>
     <br>
     <p>In carrying out these tasks, many complex business processes are involved, and a large amount of data is processed. One aspect of these 
      business processes is:</p>

      <ul>
        <li>Inspecting a property on-site and recording damages, deferred maintenance, outdated installations, fire hazards, etc.</li>
        <li>caused by tenants, pests, or emergencies.</li>
      </ul>
    </div>



    <Footer/>
    </v-app>
  </v-card>
</template>

<script>
import Footer from '@/components/Footer.vue';
import Navigation from '@/components/Navigation.vue';

export default {
  name: "Information",

  components: {
    Navigation,
    Footer
  }
}
</script>

<style scoped>
ul {
   padding-inline-start: 1.25rem;
 }

 li {
  padding: 0;
  margin-block-end: 1rem;
 }

 li:hover {
  opacity: 0.75;
 }
</style>