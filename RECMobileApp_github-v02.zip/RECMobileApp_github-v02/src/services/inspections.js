import axios from "axios";

export default {
  async getCompletedInspections() {
    try {
      const res = await axios.get(`http://localhost:3000/completedInspections`);
      return res.data;
    } catch (error) {
      console.log(error);
    }
  },
  async getScheduledInspections() {
    try {
      const res = await axios.get(`http://localhost:4000/scheduledInspections`);
      return res.data;
    } catch (error) {
      console.log(error);
    }
  }
};
