<template>
  <router-view/>
</template>

<script>
  export default {
    name: 'App',
    components: {}
  }
</script>

<style>
.main-content {
  margin-block-start: 6rem;
  margin-inline-start: 1rem;
  margin-inline-end: 1rem;
}
</style>
 